import br.ufrn.imd.view.EscolaView;

import java.text.ParseException;

public class Main {
    public static void main(String[] args) throws ParseException {
        EscolaView escolaView = new EscolaView();
        escolaView.main(args);
    }
}