package br.ufrn.imd.model;

public interface ICarbonFootprint {
    double getCarbonFootprint();
}
