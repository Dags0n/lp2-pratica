import br.ufrn.imd.view.CarboonFootprint;

public class Main {
    public static void main(String[] args) {
        CarboonFootprint carboonFootprint = new CarboonFootprint();
        carboonFootprint.main(args);
    }
}