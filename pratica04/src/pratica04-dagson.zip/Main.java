import br.ufrn.imd.view.ProgramaSaude;

public class Main {
    public static void main(String[] args) throws Exception {
        ProgramaSaude programaSaude = new ProgramaSaude();
        programaSaude.main(args);
    }
}