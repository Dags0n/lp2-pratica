import view.LocalLisa;

public class Main {
    public static void main(String[] args) {
        LocalLisa localLisa = new LocalLisa();
        localLisa.main(args);
    }
}