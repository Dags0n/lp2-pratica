import br.ufrn.imd.view.ZooView;

public class Main {
    public static void main(String[] args) {
        ZooView zooView = new ZooView();
        zooView.setVisible(true);
    }
}